DARRELL'Company — FIXED VERSION

PENTING:
1. Ekstrak ZIP terlebih dahulu, jangan menjalankan index.html langsung dari dalam ZIP.
2. Buka folder DARRELL-Company-FIXED.
3. Klik dua kali index.html.

Versi ini juga sudah menanam CSS dan JavaScript langsung di index.html, jadi tampilan tetap bekerja meskipun index.html dibuka sebagai file lokal.

Struktur tetap tersedia:
- index.html
- style.css
- script.js
- assets/products/

Password demo pembayaran: 982011
Pembayaran hanya simulasi.
